package pe.com.j2techcon.bi.etl.domain;

import java.util.ArrayList;
import java.util.List;

public class TSedeExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TSedeExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andSedeIdIsNull() {
            addCriterion("sede_id is null");
            return (Criteria) this;
        }

        public Criteria andSedeIdIsNotNull() {
            addCriterion("sede_id is not null");
            return (Criteria) this;
        }

        public Criteria andSedeIdEqualTo(Integer value) {
            addCriterion("sede_id =", value, "sedeId");
            return (Criteria) this;
        }

        public Criteria andSedeIdNotEqualTo(Integer value) {
            addCriterion("sede_id <>", value, "sedeId");
            return (Criteria) this;
        }

        public Criteria andSedeIdGreaterThan(Integer value) {
            addCriterion("sede_id >", value, "sedeId");
            return (Criteria) this;
        }

        public Criteria andSedeIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("sede_id >=", value, "sedeId");
            return (Criteria) this;
        }

        public Criteria andSedeIdLessThan(Integer value) {
            addCriterion("sede_id <", value, "sedeId");
            return (Criteria) this;
        }

        public Criteria andSedeIdLessThanOrEqualTo(Integer value) {
            addCriterion("sede_id <=", value, "sedeId");
            return (Criteria) this;
        }

        public Criteria andSedeIdIn(List<Integer> values) {
            addCriterion("sede_id in", values, "sedeId");
            return (Criteria) this;
        }

        public Criteria andSedeIdNotIn(List<Integer> values) {
            addCriterion("sede_id not in", values, "sedeId");
            return (Criteria) this;
        }

        public Criteria andSedeIdBetween(Integer value1, Integer value2) {
            addCriterion("sede_id between", value1, value2, "sedeId");
            return (Criteria) this;
        }

        public Criteria andSedeIdNotBetween(Integer value1, Integer value2) {
            addCriterion("sede_id not between", value1, value2, "sedeId");
            return (Criteria) this;
        }

        public Criteria andSedeCodIsNull() {
            addCriterion("sede_cod is null");
            return (Criteria) this;
        }

        public Criteria andSedeCodIsNotNull() {
            addCriterion("sede_cod is not null");
            return (Criteria) this;
        }

        public Criteria andSedeCodEqualTo(String value) {
            addCriterion("sede_cod =", value, "sedeCod");
            return (Criteria) this;
        }

        public Criteria andSedeCodNotEqualTo(String value) {
            addCriterion("sede_cod <>", value, "sedeCod");
            return (Criteria) this;
        }

        public Criteria andSedeCodGreaterThan(String value) {
            addCriterion("sede_cod >", value, "sedeCod");
            return (Criteria) this;
        }

        public Criteria andSedeCodGreaterThanOrEqualTo(String value) {
            addCriterion("sede_cod >=", value, "sedeCod");
            return (Criteria) this;
        }

        public Criteria andSedeCodLessThan(String value) {
            addCriterion("sede_cod <", value, "sedeCod");
            return (Criteria) this;
        }

        public Criteria andSedeCodLessThanOrEqualTo(String value) {
            addCriterion("sede_cod <=", value, "sedeCod");
            return (Criteria) this;
        }

        public Criteria andSedeCodLike(String value) {
            addCriterion("sede_cod like", value, "sedeCod");
            return (Criteria) this;
        }

        public Criteria andSedeCodNotLike(String value) {
            addCriterion("sede_cod not like", value, "sedeCod");
            return (Criteria) this;
        }

        public Criteria andSedeCodIn(List<String> values) {
            addCriterion("sede_cod in", values, "sedeCod");
            return (Criteria) this;
        }

        public Criteria andSedeCodNotIn(List<String> values) {
            addCriterion("sede_cod not in", values, "sedeCod");
            return (Criteria) this;
        }

        public Criteria andSedeCodBetween(String value1, String value2) {
            addCriterion("sede_cod between", value1, value2, "sedeCod");
            return (Criteria) this;
        }

        public Criteria andSedeCodNotBetween(String value1, String value2) {
            addCriterion("sede_cod not between", value1, value2, "sedeCod");
            return (Criteria) this;
        }

        public Criteria andSedeCodUbiIsNull() {
            addCriterion("sede_cod_ubi is null");
            return (Criteria) this;
        }

        public Criteria andSedeCodUbiIsNotNull() {
            addCriterion("sede_cod_ubi is not null");
            return (Criteria) this;
        }

        public Criteria andSedeCodUbiEqualTo(Integer value) {
            addCriterion("sede_cod_ubi =", value, "sedeCodUbi");
            return (Criteria) this;
        }

        public Criteria andSedeCodUbiNotEqualTo(Integer value) {
            addCriterion("sede_cod_ubi <>", value, "sedeCodUbi");
            return (Criteria) this;
        }

        public Criteria andSedeCodUbiGreaterThan(Integer value) {
            addCriterion("sede_cod_ubi >", value, "sedeCodUbi");
            return (Criteria) this;
        }

        public Criteria andSedeCodUbiGreaterThanOrEqualTo(Integer value) {
            addCriterion("sede_cod_ubi >=", value, "sedeCodUbi");
            return (Criteria) this;
        }

        public Criteria andSedeCodUbiLessThan(Integer value) {
            addCriterion("sede_cod_ubi <", value, "sedeCodUbi");
            return (Criteria) this;
        }

        public Criteria andSedeCodUbiLessThanOrEqualTo(Integer value) {
            addCriterion("sede_cod_ubi <=", value, "sedeCodUbi");
            return (Criteria) this;
        }

        public Criteria andSedeCodUbiIn(List<Integer> values) {
            addCriterion("sede_cod_ubi in", values, "sedeCodUbi");
            return (Criteria) this;
        }

        public Criteria andSedeCodUbiNotIn(List<Integer> values) {
            addCriterion("sede_cod_ubi not in", values, "sedeCodUbi");
            return (Criteria) this;
        }

        public Criteria andSedeCodUbiBetween(Integer value1, Integer value2) {
            addCriterion("sede_cod_ubi between", value1, value2, "sedeCodUbi");
            return (Criteria) this;
        }

        public Criteria andSedeCodUbiNotBetween(Integer value1, Integer value2) {
            addCriterion("sede_cod_ubi not between", value1, value2, "sedeCodUbi");
            return (Criteria) this;
        }

        public Criteria andSedeCodTipIsNull() {
            addCriterion("sede_cod_tip is null");
            return (Criteria) this;
        }

        public Criteria andSedeCodTipIsNotNull() {
            addCriterion("sede_cod_tip is not null");
            return (Criteria) this;
        }

        public Criteria andSedeCodTipEqualTo(Integer value) {
            addCriterion("sede_cod_tip =", value, "sedeCodTip");
            return (Criteria) this;
        }

        public Criteria andSedeCodTipNotEqualTo(Integer value) {
            addCriterion("sede_cod_tip <>", value, "sedeCodTip");
            return (Criteria) this;
        }

        public Criteria andSedeCodTipGreaterThan(Integer value) {
            addCriterion("sede_cod_tip >", value, "sedeCodTip");
            return (Criteria) this;
        }

        public Criteria andSedeCodTipGreaterThanOrEqualTo(Integer value) {
            addCriterion("sede_cod_tip >=", value, "sedeCodTip");
            return (Criteria) this;
        }

        public Criteria andSedeCodTipLessThan(Integer value) {
            addCriterion("sede_cod_tip <", value, "sedeCodTip");
            return (Criteria) this;
        }

        public Criteria andSedeCodTipLessThanOrEqualTo(Integer value) {
            addCriterion("sede_cod_tip <=", value, "sedeCodTip");
            return (Criteria) this;
        }

        public Criteria andSedeCodTipIn(List<Integer> values) {
            addCriterion("sede_cod_tip in", values, "sedeCodTip");
            return (Criteria) this;
        }

        public Criteria andSedeCodTipNotIn(List<Integer> values) {
            addCriterion("sede_cod_tip not in", values, "sedeCodTip");
            return (Criteria) this;
        }

        public Criteria andSedeCodTipBetween(Integer value1, Integer value2) {
            addCriterion("sede_cod_tip between", value1, value2, "sedeCodTip");
            return (Criteria) this;
        }

        public Criteria andSedeCodTipNotBetween(Integer value1, Integer value2) {
            addCriterion("sede_cod_tip not between", value1, value2, "sedeCodTip");
            return (Criteria) this;
        }

        public Criteria andSedeDesDirIsNull() {
            addCriterion("sede_des_dir is null");
            return (Criteria) this;
        }

        public Criteria andSedeDesDirIsNotNull() {
            addCriterion("sede_des_dir is not null");
            return (Criteria) this;
        }

        public Criteria andSedeDesDirEqualTo(String value) {
            addCriterion("sede_des_dir =", value, "sedeDesDir");
            return (Criteria) this;
        }

        public Criteria andSedeDesDirNotEqualTo(String value) {
            addCriterion("sede_des_dir <>", value, "sedeDesDir");
            return (Criteria) this;
        }

        public Criteria andSedeDesDirGreaterThan(String value) {
            addCriterion("sede_des_dir >", value, "sedeDesDir");
            return (Criteria) this;
        }

        public Criteria andSedeDesDirGreaterThanOrEqualTo(String value) {
            addCriterion("sede_des_dir >=", value, "sedeDesDir");
            return (Criteria) this;
        }

        public Criteria andSedeDesDirLessThan(String value) {
            addCriterion("sede_des_dir <", value, "sedeDesDir");
            return (Criteria) this;
        }

        public Criteria andSedeDesDirLessThanOrEqualTo(String value) {
            addCriterion("sede_des_dir <=", value, "sedeDesDir");
            return (Criteria) this;
        }

        public Criteria andSedeDesDirLike(String value) {
            addCriterion("sede_des_dir like", value, "sedeDesDir");
            return (Criteria) this;
        }

        public Criteria andSedeDesDirNotLike(String value) {
            addCriterion("sede_des_dir not like", value, "sedeDesDir");
            return (Criteria) this;
        }

        public Criteria andSedeDesDirIn(List<String> values) {
            addCriterion("sede_des_dir in", values, "sedeDesDir");
            return (Criteria) this;
        }

        public Criteria andSedeDesDirNotIn(List<String> values) {
            addCriterion("sede_des_dir not in", values, "sedeDesDir");
            return (Criteria) this;
        }

        public Criteria andSedeDesDirBetween(String value1, String value2) {
            addCriterion("sede_des_dir between", value1, value2, "sedeDesDir");
            return (Criteria) this;
        }

        public Criteria andSedeDesDirNotBetween(String value1, String value2) {
            addCriterion("sede_des_dir not between", value1, value2, "sedeDesDir");
            return (Criteria) this;
        }

        public Criteria andFecNumCamIsNull() {
            addCriterion("fec_num_cam is null");
            return (Criteria) this;
        }

        public Criteria andFecNumCamIsNotNull() {
            addCriterion("fec_num_cam is not null");
            return (Criteria) this;
        }

        public Criteria andFecNumCamEqualTo(Integer value) {
            addCriterion("fec_num_cam =", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamNotEqualTo(Integer value) {
            addCriterion("fec_num_cam <>", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamGreaterThan(Integer value) {
            addCriterion("fec_num_cam >", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamGreaterThanOrEqualTo(Integer value) {
            addCriterion("fec_num_cam >=", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamLessThan(Integer value) {
            addCriterion("fec_num_cam <", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamLessThanOrEqualTo(Integer value) {
            addCriterion("fec_num_cam <=", value, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamIn(List<Integer> values) {
            addCriterion("fec_num_cam in", values, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamNotIn(List<Integer> values) {
            addCriterion("fec_num_cam not in", values, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamBetween(Integer value1, Integer value2) {
            addCriterion("fec_num_cam between", value1, value2, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andFecNumCamNotBetween(Integer value1, Integer value2) {
            addCriterion("fec_num_cam not between", value1, value2, "fecNumCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamIsNull() {
            addCriterion("cod_ind_cam is null");
            return (Criteria) this;
        }

        public Criteria andCodIndCamIsNotNull() {
            addCriterion("cod_ind_cam is not null");
            return (Criteria) this;
        }

        public Criteria andCodIndCamEqualTo(String value) {
            addCriterion("cod_ind_cam =", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamNotEqualTo(String value) {
            addCriterion("cod_ind_cam <>", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamGreaterThan(String value) {
            addCriterion("cod_ind_cam >", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamGreaterThanOrEqualTo(String value) {
            addCriterion("cod_ind_cam >=", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamLessThan(String value) {
            addCriterion("cod_ind_cam <", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamLessThanOrEqualTo(String value) {
            addCriterion("cod_ind_cam <=", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamLike(String value) {
            addCriterion("cod_ind_cam like", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamNotLike(String value) {
            addCriterion("cod_ind_cam not like", value, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamIn(List<String> values) {
            addCriterion("cod_ind_cam in", values, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamNotIn(List<String> values) {
            addCriterion("cod_ind_cam not in", values, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamBetween(String value1, String value2) {
            addCriterion("cod_ind_cam between", value1, value2, "codIndCam");
            return (Criteria) this;
        }

        public Criteria andCodIndCamNotBetween(String value1, String value2) {
            addCriterion("cod_ind_cam not between", value1, value2, "codIndCam");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}