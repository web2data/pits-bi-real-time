package pe.com.j2techcon.bi.etl.domain;

public class TCliente {
    private Integer cliId;

    private Integer cliCodTip;

    private Integer cliCodCat;

    private String cliCodTipDoc;

    private String cliNumTipDoc;

    private String cliDesRazSoc;

    private String cliDesApePat;

    private String cliDesApeMat;

    private String cliDesNom;

    private Integer cliCodUbi;

    private Integer cliCodTipFac;

    private Integer cliCodTipCre;

    private String cliCod;

    private String cliNumTel;

    private String cliDesCor;

    private String cliDesDir;

    private Integer cliCodEst;

    private Integer fecNumCam;

    private String codIndCam;

    public Integer getCliId() {
        return cliId;
    }

    public void setCliId(Integer cliId) {
        this.cliId = cliId;
    }

    public Integer getCliCodTip() {
        return cliCodTip;
    }

    public void setCliCodTip(Integer cliCodTip) {
        this.cliCodTip = cliCodTip;
    }

    public Integer getCliCodCat() {
        return cliCodCat;
    }

    public void setCliCodCat(Integer cliCodCat) {
        this.cliCodCat = cliCodCat;
    }

    public String getCliCodTipDoc() {
        return cliCodTipDoc;
    }

    public void setCliCodTipDoc(String cliCodTipDoc) {
        this.cliCodTipDoc = cliCodTipDoc == null ? null : cliCodTipDoc.trim();
    }

    public String getCliNumTipDoc() {
        return cliNumTipDoc;
    }

    public void setCliNumTipDoc(String cliNumTipDoc) {
        this.cliNumTipDoc = cliNumTipDoc == null ? null : cliNumTipDoc.trim();
    }

    public String getCliDesRazSoc() {
        return cliDesRazSoc;
    }

    public void setCliDesRazSoc(String cliDesRazSoc) {
        this.cliDesRazSoc = cliDesRazSoc == null ? null : cliDesRazSoc.trim();
    }

    public String getCliDesApePat() {
        return cliDesApePat;
    }

    public void setCliDesApePat(String cliDesApePat) {
        this.cliDesApePat = cliDesApePat == null ? null : cliDesApePat.trim();
    }

    public String getCliDesApeMat() {
        return cliDesApeMat;
    }

    public void setCliDesApeMat(String cliDesApeMat) {
        this.cliDesApeMat = cliDesApeMat == null ? null : cliDesApeMat.trim();
    }

    public String getCliDesNom() {
        return cliDesNom;
    }

    public void setCliDesNom(String cliDesNom) {
        this.cliDesNom = cliDesNom == null ? null : cliDesNom.trim();
    }

    public Integer getCliCodUbi() {
        return cliCodUbi;
    }

    public void setCliCodUbi(Integer cliCodUbi) {
        this.cliCodUbi = cliCodUbi;
    }

    public Integer getCliCodTipFac() {
        return cliCodTipFac;
    }

    public void setCliCodTipFac(Integer cliCodTipFac) {
        this.cliCodTipFac = cliCodTipFac;
    }

    public Integer getCliCodTipCre() {
        return cliCodTipCre;
    }

    public void setCliCodTipCre(Integer cliCodTipCre) {
        this.cliCodTipCre = cliCodTipCre;
    }

    public String getCliCod() {
        return cliCod;
    }

    public void setCliCod(String cliCod) {
        this.cliCod = cliCod == null ? null : cliCod.trim();
    }

    public String getCliNumTel() {
        return cliNumTel;
    }

    public void setCliNumTel(String cliNumTel) {
        this.cliNumTel = cliNumTel == null ? null : cliNumTel.trim();
    }

    public String getCliDesCor() {
        return cliDesCor;
    }

    public void setCliDesCor(String cliDesCor) {
        this.cliDesCor = cliDesCor == null ? null : cliDesCor.trim();
    }

    public String getCliDesDir() {
        return cliDesDir;
    }

    public void setCliDesDir(String cliDesDir) {
        this.cliDesDir = cliDesDir == null ? null : cliDesDir.trim();
    }

    public Integer getCliCodEst() {
        return cliCodEst;
    }

    public void setCliCodEst(Integer cliCodEst) {
        this.cliCodEst = cliCodEst;
    }

    public Integer getFecNumCam() {
        return fecNumCam;
    }

    public void setFecNumCam(Integer fecNumCam) {
        this.fecNumCam = fecNumCam;
    }

    public String getCodIndCam() {
        return codIndCam;
    }

    public void setCodIndCam(String codIndCam) {
        this.codIndCam = codIndCam == null ? null : codIndCam.trim();
    }
}