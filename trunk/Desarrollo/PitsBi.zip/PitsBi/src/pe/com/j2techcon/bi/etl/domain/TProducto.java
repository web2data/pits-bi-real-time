package pe.com.j2techcon.bi.etl.domain;

import java.math.BigDecimal;

public class TProducto {
    private Integer prodId;

    private Integer prodCodTip;

    private Integer prodCodAmb;

    private Integer prodCodServ;

    private String prodCod;

    private String prodDes;

    private BigDecimal prodPre;

    private Integer fecNumCam;

    private String codIndCam;

    public Integer getProdId() {
        return prodId;
    }

    public void setProdId(Integer prodId) {
        this.prodId = prodId;
    }

    public Integer getProdCodTip() {
        return prodCodTip;
    }

    public void setProdCodTip(Integer prodCodTip) {
        this.prodCodTip = prodCodTip;
    }

    public Integer getProdCodAmb() {
        return prodCodAmb;
    }

    public void setProdCodAmb(Integer prodCodAmb) {
        this.prodCodAmb = prodCodAmb;
    }

    public Integer getProdCodServ() {
        return prodCodServ;
    }

    public void setProdCodServ(Integer prodCodServ) {
        this.prodCodServ = prodCodServ;
    }

    public String getProdCod() {
        return prodCod;
    }

    public void setProdCod(String prodCod) {
        this.prodCod = prodCod == null ? null : prodCod.trim();
    }

    public String getProdDes() {
        return prodDes;
    }

    public void setProdDes(String prodDes) {
        this.prodDes = prodDes == null ? null : prodDes.trim();
    }

    public BigDecimal getProdPre() {
        return prodPre;
    }

    public void setProdPre(BigDecimal prodPre) {
        this.prodPre = prodPre;
    }

    public Integer getFecNumCam() {
        return fecNumCam;
    }

    public void setFecNumCam(Integer fecNumCam) {
        this.fecNumCam = fecNumCam;
    }

    public String getCodIndCam() {
        return codIndCam;
    }

    public void setCodIndCam(String codIndCam) {
        this.codIndCam = codIndCam == null ? null : codIndCam.trim();
    }
}