package pe.com.j2techcon.bi.etl.domain;

import java.math.BigDecimal;
import java.util.Date;

public class TDespacho {
    private Integer despId;

    private Integer despCodTipDoc;

    private String despSerieDoc;

    private String despNumeroDoc;

    private Integer sedeId;

    private Integer empCatId;

    private Integer despCodTipEnv;

    private Integer despCodUbi;

    private Integer despCodTipRut;

    private Integer despCodZon;

    private Integer despCodVer;

    private BigDecimal despNomPasaje;

    private Integer despNumCargos;

    private Date despFecSal;

    private Date despFecRetPro;

    private Date despFecRetRea;

    private Date despFecVer;

    private BigDecimal despCanPas;

    private Integer despCodEst;

    private Integer fecNumCam;

    private String codIndCam;

    public Integer getDespId() {
        return despId;
    }

    public void setDespId(Integer despId) {
        this.despId = despId;
    }

    public Integer getDespCodTipDoc() {
        return despCodTipDoc;
    }

    public void setDespCodTipDoc(Integer despCodTipDoc) {
        this.despCodTipDoc = despCodTipDoc;
    }

    public String getDespSerieDoc() {
        return despSerieDoc;
    }

    public void setDespSerieDoc(String despSerieDoc) {
        this.despSerieDoc = despSerieDoc == null ? null : despSerieDoc.trim();
    }

    public String getDespNumeroDoc() {
        return despNumeroDoc;
    }

    public void setDespNumeroDoc(String despNumeroDoc) {
        this.despNumeroDoc = despNumeroDoc == null ? null : despNumeroDoc.trim();
    }

    public Integer getSedeId() {
        return sedeId;
    }

    public void setSedeId(Integer sedeId) {
        this.sedeId = sedeId;
    }

    public Integer getEmpCatId() {
        return empCatId;
    }

    public void setEmpCatId(Integer empCatId) {
        this.empCatId = empCatId;
    }

    public Integer getDespCodTipEnv() {
        return despCodTipEnv;
    }

    public void setDespCodTipEnv(Integer despCodTipEnv) {
        this.despCodTipEnv = despCodTipEnv;
    }

    public Integer getDespCodUbi() {
        return despCodUbi;
    }

    public void setDespCodUbi(Integer despCodUbi) {
        this.despCodUbi = despCodUbi;
    }

    public Integer getDespCodTipRut() {
        return despCodTipRut;
    }

    public void setDespCodTipRut(Integer despCodTipRut) {
        this.despCodTipRut = despCodTipRut;
    }

    public Integer getDespCodZon() {
        return despCodZon;
    }

    public void setDespCodZon(Integer despCodZon) {
        this.despCodZon = despCodZon;
    }

    public Integer getDespCodVer() {
        return despCodVer;
    }

    public void setDespCodVer(Integer despCodVer) {
        this.despCodVer = despCodVer;
    }

    public BigDecimal getDespNomPasaje() {
        return despNomPasaje;
    }

    public void setDespNomPasaje(BigDecimal despNomPasaje) {
        this.despNomPasaje = despNomPasaje;
    }

    public Integer getDespNumCargos() {
        return despNumCargos;
    }

    public void setDespNumCargos(Integer despNumCargos) {
        this.despNumCargos = despNumCargos;
    }

    public Date getDespFecSal() {
        return despFecSal;
    }

    public void setDespFecSal(Date despFecSal) {
        this.despFecSal = despFecSal;
    }

    public Date getDespFecRetPro() {
        return despFecRetPro;
    }

    public void setDespFecRetPro(Date despFecRetPro) {
        this.despFecRetPro = despFecRetPro;
    }

    public Date getDespFecRetRea() {
        return despFecRetRea;
    }

    public void setDespFecRetRea(Date despFecRetRea) {
        this.despFecRetRea = despFecRetRea;
    }

    public Date getDespFecVer() {
        return despFecVer;
    }

    public void setDespFecVer(Date despFecVer) {
        this.despFecVer = despFecVer;
    }

    public BigDecimal getDespCanPas() {
        return despCanPas;
    }

    public void setDespCanPas(BigDecimal despCanPas) {
        this.despCanPas = despCanPas;
    }

    public Integer getDespCodEst() {
        return despCodEst;
    }

    public void setDespCodEst(Integer despCodEst) {
        this.despCodEst = despCodEst;
    }

    public Integer getFecNumCam() {
        return fecNumCam;
    }

    public void setFecNumCam(Integer fecNumCam) {
        this.fecNumCam = fecNumCam;
    }

    public String getCodIndCam() {
        return codIndCam;
    }

    public void setCodIndCam(String codIndCam) {
        this.codIndCam = codIndCam == null ? null : codIndCam.trim();
    }
}