package pe.com.j2techcon.bi.etl.domain;

public class TSede {
    private Integer sedeId;

    private String sedeCod;

    private Integer sedeCodUbi;

    private Integer sedeCodTip;

    private String sedeDesDir;

    private Integer fecNumCam;

    private String codIndCam;

    public Integer getSedeId() {
        return sedeId;
    }

    public void setSedeId(Integer sedeId) {
        this.sedeId = sedeId;
    }

    public String getSedeCod() {
        return sedeCod;
    }

    public void setSedeCod(String sedeCod) {
        this.sedeCod = sedeCod == null ? null : sedeCod.trim();
    }

    public Integer getSedeCodUbi() {
        return sedeCodUbi;
    }

    public void setSedeCodUbi(Integer sedeCodUbi) {
        this.sedeCodUbi = sedeCodUbi;
    }

    public Integer getSedeCodTip() {
        return sedeCodTip;
    }

    public void setSedeCodTip(Integer sedeCodTip) {
        this.sedeCodTip = sedeCodTip;
    }

    public String getSedeDesDir() {
        return sedeDesDir;
    }

    public void setSedeDesDir(String sedeDesDir) {
        this.sedeDesDir = sedeDesDir == null ? null : sedeDesDir.trim();
    }

    public Integer getFecNumCam() {
        return fecNumCam;
    }

    public void setFecNumCam(Integer fecNumCam) {
        this.fecNumCam = fecNumCam;
    }

    public String getCodIndCam() {
        return codIndCam;
    }

    public void setCodIndCam(String codIndCam) {
        this.codIndCam = codIndCam == null ? null : codIndCam.trim();
    }
}