package pe.com.j2techcon.bi.etl.logic;

import java.util.List;

import pe.com.j2techcon.bi.etl.dao.TResultadoDespachoMapper;
import pe.com.j2techcon.bi.etl.domain.TResultadoDespacho;
import pe.com.j2techcon.bi.etl.domain.TResultadoDespachoExample;

public class TResultadoDespachoManager {
	
	private TResultadoDespachoMapper tResultadoDespachoMapper;
	

	public TResultadoDespachoMapper gettResultadoDespachoMapper() {
		return tResultadoDespachoMapper;
	}

	public void settResultadoDespachoMapper(
			TResultadoDespachoMapper tResultadoDespachoMapper) {
		this.tResultadoDespachoMapper = tResultadoDespachoMapper;
	}


	public int countByExample(TResultadoDespachoExample example) {
		return tResultadoDespachoMapper.countByExample(example);
	}


	public int deleteByExample(TResultadoDespachoExample example) {
		return tResultadoDespachoMapper.deleteByExample(example);
	}


	public int deleteByPrimaryKey(Integer resDesId) {
		return tResultadoDespachoMapper.deleteByPrimaryKey(resDesId);
	}


	public int insert(TResultadoDespacho record) {
		return tResultadoDespachoMapper.insert(record);
	}


	public int insertSelective(TResultadoDespacho record) {
		return tResultadoDespachoMapper.insertSelective(record);
	}


	public List<TResultadoDespacho> selectByExample(
			TResultadoDespachoExample example) {
		return tResultadoDespachoMapper.selectByExample(example);
	}


	public TResultadoDespacho selectByPrimaryKey(Integer resDesId) {
		return tResultadoDespachoMapper.selectByPrimaryKey(resDesId);
	}


	public int updateByExampleSelective(TResultadoDespacho record,
			TResultadoDespachoExample example) {
		return tResultadoDespachoMapper.updateByExampleSelective(record, example);
	}


	public int updateByExample(TResultadoDespacho record,
			TResultadoDespachoExample example) {
		return tResultadoDespachoMapper.updateByExample(record, example);
	}


	public int updateByPrimaryKeySelective(TResultadoDespacho record) {
		return tResultadoDespachoMapper.updateByPrimaryKeySelective(record);
	}


	public int updateByPrimaryKey(TResultadoDespacho record) {
		return tResultadoDespachoMapper.updateByPrimaryKey(record);
	}

}
