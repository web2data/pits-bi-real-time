package pe.com.j2techcon.bi.etl.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import pe.com.j2techcon.bi.etl.domain.TResultadoDespacho;
import pe.com.j2techcon.bi.etl.domain.TResultadoDespachoExample;

public interface TResultadoDespachoMapper {
    int countByExample(TResultadoDespachoExample example);

    int deleteByExample(TResultadoDespachoExample example);

    int deleteByPrimaryKey(Integer resDesId);

    int insert(TResultadoDespacho record);

    int insertSelective(TResultadoDespacho record);

    List<TResultadoDespacho> selectByExample(TResultadoDespachoExample example);

    TResultadoDespacho selectByPrimaryKey(Integer resDesId);

    int updateByExampleSelective(@Param("record") TResultadoDespacho record, @Param("example") TResultadoDespachoExample example);

    int updateByExample(@Param("record") TResultadoDespacho record, @Param("example") TResultadoDespachoExample example);

    int updateByPrimaryKeySelective(TResultadoDespacho record);

    int updateByPrimaryKey(TResultadoDespacho record);
}