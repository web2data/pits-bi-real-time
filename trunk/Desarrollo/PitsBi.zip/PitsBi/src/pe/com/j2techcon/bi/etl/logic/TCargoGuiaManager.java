package pe.com.j2techcon.bi.etl.logic;

import java.util.List;

import pe.com.j2techcon.bi.etl.dao.TCargoGuiaMapper;
import pe.com.j2techcon.bi.etl.domain.TCargoGuia;
import pe.com.j2techcon.bi.etl.domain.TCargoGuiaExample;

public class TCargoGuiaManager {

	
	private TCargoGuiaMapper tCargoGuiaMapper;
	
	
	public TCargoGuiaMapper gettCargoGuiaMapper() {
		return tCargoGuiaMapper;
	}

	public void settCargoGuiaMapper(TCargoGuiaMapper tCargoGuiaMapper) {
		this.tCargoGuiaMapper = tCargoGuiaMapper;
	}


	public int countByExample(TCargoGuiaExample example) {
		return tCargoGuiaMapper.countByExample(example);
	}


	public int deleteByExample(TCargoGuiaExample example) {
		return tCargoGuiaMapper.deleteByExample(example);
	}


	public int deleteByPrimaryKey(Integer carGuiId) {
		return tCargoGuiaMapper.deleteByPrimaryKey(carGuiId);
	}


	public int insert(TCargoGuia record) {
		return tCargoGuiaMapper.insert(record);
	}


	public int insertSelective(TCargoGuia record) {
		return tCargoGuiaMapper.insertSelective(record);
	}


	public List<TCargoGuia> selectByExample(TCargoGuiaExample example) {
		return tCargoGuiaMapper.selectByExample(example);
	}


	public TCargoGuia selectByPrimaryKey(Integer carGuiId) {
		return tCargoGuiaMapper.selectByPrimaryKey(carGuiId);
	}


	public int updateByExampleSelective(TCargoGuia record,
			TCargoGuiaExample example) {
		return tCargoGuiaMapper.updateByExampleSelective(record, example);
	}


	public int updateByExample(TCargoGuia record, TCargoGuiaExample example) {
		return tCargoGuiaMapper.updateByExample(record, example);
	}


	public int updateByPrimaryKeySelective(TCargoGuia record) {
		return tCargoGuiaMapper.updateByPrimaryKeySelective(record);
	}


	public int updateByPrimaryKey(TCargoGuia record) {
		return tCargoGuiaMapper.updateByPrimaryKey(record);
	}

}
