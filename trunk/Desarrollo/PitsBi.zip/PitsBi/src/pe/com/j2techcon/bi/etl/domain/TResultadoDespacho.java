package pe.com.j2techcon.bi.etl.domain;

public class TResultadoDespacho {
    private Integer resDesId;

    private Integer despId;

    private Integer resDesCodMov;

    private Integer resDesNumCargos;

    private Integer resDesCodEst;

    private Integer fecNumCam;

    private String codIndCam;

    public Integer getResDesId() {
        return resDesId;
    }

    public void setResDesId(Integer resDesId) {
        this.resDesId = resDesId;
    }

    public Integer getDespId() {
        return despId;
    }

    public void setDespId(Integer despId) {
        this.despId = despId;
    }

    public Integer getResDesCodMov() {
        return resDesCodMov;
    }

    public void setResDesCodMov(Integer resDesCodMov) {
        this.resDesCodMov = resDesCodMov;
    }

    public Integer getResDesNumCargos() {
        return resDesNumCargos;
    }

    public void setResDesNumCargos(Integer resDesNumCargos) {
        this.resDesNumCargos = resDesNumCargos;
    }

    public Integer getResDesCodEst() {
        return resDesCodEst;
    }

    public void setResDesCodEst(Integer resDesCodEst) {
        this.resDesCodEst = resDesCodEst;
    }

    public Integer getFecNumCam() {
        return fecNumCam;
    }

    public void setFecNumCam(Integer fecNumCam) {
        this.fecNumCam = fecNumCam;
    }

    public String getCodIndCam() {
        return codIndCam;
    }

    public void setCodIndCam(String codIndCam) {
        this.codIndCam = codIndCam == null ? null : codIndCam.trim();
    }
}